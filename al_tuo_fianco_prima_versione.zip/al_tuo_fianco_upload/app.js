const WHATSAPP_NUMBER = '393000000000'; // Sostituisci con il tuo numero, es. 393491234567

const form = document.getElementById('requestForm');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const nome = document.getElementById('nome').value.trim();
  const telefono = document.getElementById('telefono').value.trim();
  const comune = document.getElementById('comune').value.trim();
  const servizio = document.getElementById('servizio').value;
  const data = document.getElementById('data').value;
  const note = document.getElementById('note').value.trim();

  const message = `Ciao, vorrei richiedere un servizio con Al tuo fianco.%0A%0A` +
    `Nome: ${encodeURIComponent(nome)}%0A` +
    `Telefono: ${encodeURIComponent(telefono)}%0A` +
    `Comune: ${encodeURIComponent(comune)}%0A` +
    `Servizio: ${encodeURIComponent(servizio)}%0A` +
    `Data preferita: ${encodeURIComponent(data)}%0A` +
    `Note: ${encodeURIComponent(note)}`;

  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
