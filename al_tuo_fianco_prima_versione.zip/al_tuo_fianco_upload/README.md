# Al tuo fianco app

Prima versione web app installabile per servizi di accompagnamento, pratiche, commissioni e supporto quotidiano nel Sulcis.

## Cose da modificare subito

Nel file `app.js` cambia questo numero:

```js
const WHATSAPP_NUMBER = '393000000000';
```

Inserisci il tuo numero WhatsApp in formato internazionale, senza + e senza spazi.
Esempio: `393491234567`.
